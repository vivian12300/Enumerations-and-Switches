import Cocoa

var greeting = "Hello, playground"

enum Sandwiches {
    case turkeySandwich
    case chiceknSandwich
    case beefSandwich
    case veggieSandwich
}

var sandwichChoice = Sandwiches.turkeySandwich

switch sandwichChoice {
case .turkeySandwich:
    print("Turkey sandwich confirmed!")
case .chiceknSandwich:
    print("Chicken sandwich confirmed!")
case .beefSandwich:
    print("Beef sandwich confirmed!")
case .veggieSandwich:
    print("Veggie sandwich confirmed!")
}
